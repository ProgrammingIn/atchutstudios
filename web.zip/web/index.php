<?php
session_start();

// Database connection
$db = mysqli_connect("localhost", "root", "root$1234", "tutor");

// If upload button is clicked ...
if (isset($_POST['upload'])) {

    $title = mysqli_real_escape_string($db, $_POST['title']);
    $description = mysqli_real_escape_string($db, $_POST['description']);
    $language = mysqli_real_escape_string($db, $_POST['language']);
    $slideshow = mysqli_real_escape_string($db, $_POST['slideshow']);
    $recent = mysqli_real_escape_string($db, $_POST['recent']);
    $type = mysqli_real_escape_string($db, $_POST['type']);
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];

    // Get the file extension
    $ext = pathinfo($filename, PATHINFO_EXTENSION);

    // Generate a new file name using current timestamp
    $new_filename = "image_" . date("Ymd_His") . "_" . rand(1000, 9999) . "." . $ext;

    $folder = "./image/" . $new_filename;

    // Insert all data into the database
    $sql = "INSERT INTO image (filename, title, description, language, slideshow, recent, type) 
            VALUES ('$new_filename', '$title', '$description', '$language', '$slideshow', '$recent', '$type')";
    mysqli_query($db, $sql);

    // Move the uploaded image to the folder
    if (move_uploaded_file($tempname, $folder)) {
        echo "<h3>&nbsp; Image uploaded successfully!</h3>";
    } else {
        echo "<h3>&nbsp; Failed to upload image!</h3>";
    }
}

// If delete button is clicked ...
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $filename = $_POST['filename'];

    // Delete the image from the database
    $sql = "DELETE FROM image WHERE id = $id";
    mysqli_query($db, $sql);

    // Delete the image file from the folder
    $filePath = "./image/" . $filename;
    if (file_exists($filePath)) {
        unlink($filePath);
    }

    echo "<h3>&nbsp; Image deleted successfully!</h3>";
}
// Logout functionality
if (isset($_POST['logout'])) {
    // Destroy the session to logout the user
    session_destroy();
    header('Location: login.php'); // Redirect to login page after logout
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Image Upload with Multiple Attributes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<?php 
if (isset($_SESSION['username'])): ?>
<div style="justify-content: right;">
    <form method="post">
        <button type="submit" name="logout" class="btn btn-danger">Logout</button>
    </form>
</div>
<?php else: ?>
    <a href="login.php" class="btn btn-primary">Login</a>
<?php endif; ?>
<body>
    <div id="content">
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Title</label>
                <input class="form-control" type="text" name="title" id="title" placeholder="Enter title" required />
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" name="description" id="description" rows="3" placeholder="Enter description" required></textarea>
            </div>
            <div class="form-group">
                <label for="language">Language</label>
                <input class="form-control" type="text" name="language" id="language" placeholder="Enter language" required />
            </div>
            <div class="form-group">
                <label for="slideshow">Slideshow</label>
                <select class="form-control" name="slideshow" id="slideshow">
                    <option value="Y">Yes</option>
                    <option value="N">No</option>
                </select>
            </div>
            <div class="form-group">
                <label for="recent">Recent</label>
                <select class="form-control" name="recent" id="recent">
                    <option value="Y">Yes</option>
                    <option value="N">No</option>
                </select>
            </div>
            <div class="form-group">
                <label for="type">Type</label>
                <select class="form-control" name="type" id="type">
                    <option value="Film">Film</option>
                    <option value="Web Series">Web Series</option>
                    <option value="Serial">Serial</option>
                </select>
            </div>
            <div class="form-group">
                <label for="uploadfile">Upload Image</label>
                <input class="form-control" type="file" name="uploadfile" id="uploadfile" required />
            </div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit" name="upload">UPLOAD</button>
            </div>
        </form>
    </div>

    <div id="display-image" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 20px; padding: 30px;">
    <?php
    $query = "SELECT * FROM image";
    $result = mysqli_query($db, $query);

    while ($data = mysqli_fetch_assoc($result)) {
    ?>
    <div style="text-align: center; border: 1px solid #ddd; border-radius: 8px; padding: 10px; background-color: #f9f9f9;">
        <img src="./image/<?php echo $data['filename']; ?>" height="180" width="120" style="object-fit: fill; border-radius: 5px;" />
        <h5><?php echo htmlspecialchars($data['title']); ?></h5>
        <p><strong>Description:</strong> <?php echo htmlspecialchars($data['description']); ?></p>
        <p><strong>Language:</strong> <?php echo htmlspecialchars($data['language']); ?></p>
        <p><strong>Slideshow:</strong> <?php echo htmlspecialchars($data['slideshow']); ?></p>
        <p><strong>Recent:</strong> <?php echo htmlspecialchars($data['recent']); ?></p>
        <p><strong>Type:</strong> <?php echo htmlspecialchars($data['type']); ?></p>
        <form method="POST" action="" style="margin-top: 10px;">
            <input type="hidden" name="id" value="<?php echo $data['id']; ?>" />
            <input type="hidden" name="filename" value="<?php echo $data['filename']; ?>" />
            <button class="btn btn-danger btn-sm" type="submit" name="delete">DELETE</button>
        </form>
    </div>
    <?php
    }
    ?>
</div>

</body>

<!-- Check if the user is logged in -->


</html>
