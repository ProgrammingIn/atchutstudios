<?php
// Database connection
$db = mysqli_connect("localhost", "root", "root$1234", "tutor");

// Fetch all images for the slideshow
$slideshow_query = "SELECT * FROM image WHERE slideshow = 'Y'";
$slideshow_result = mysqli_query($db, $slideshow_query);

// Fetch recent films
$recent_films_query = "SELECT * FROM image WHERE recent = 'Y' AND type = 'Film' ORDER BY id DESC LIMIT 10";
$recent_films_result = mysqli_query($db, $recent_films_query);

// Fetch recent web series
$recent_webseries_query = "SELECT * FROM image WHERE recent = 'Y' AND type = 'Web Series' ORDER BY id DESC LIMIT 10";
$recent_webseries_result = mysqli_query($db, $recent_webseries_query);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Homepage</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <style>
  body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #fff; /* Optional: Adds contrast */
  }

  /* Header */
  .header {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px 20px;
    background: linear-gradient(to right, #f4f4f4, #eaeaea);
    color: #8B4513;
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
  }

  .header h1 {
    margin: 0;
    font-size: 32px;
    font-weight: bold;
  }

  .nav {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 10px;
  }

  .nav a {
    text-decoration: none;
    color: #8B4513;
    font-size: 18px;
    font-weight: bold;
    transition: color 0.3s ease;
  }

  .nav a:hover {
    color: #DAA520; /* Goldenrod hover effect */
  }

  /* Slideshow */
  .slideshow {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 84vh;
    margin: 0 auto;
    background-color: #000; /* Adds contrast */
    overflow: hidden;
  }

  .slideshow img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain; /* Ensures images fit properly */
    border-radius: 10px; /* Optional: Adds rounded corners */
    transition: transform 0.3s ease-in-out;
  }

  .slideshow img:hover {
    transform: scale(1.05); /* Slight zoom on hover */
  }

  .section-title {
            margin: 20px 0;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
        }

        .card-deck {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
        }

        .card {
            width: calc(16% - 10px);
            /* Adjust card size for 6 cards per row */
            margin: 10px 0;
        }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: contain;
            /* Ensures the entire image is visible */
            background-color: #f4f4f4;
            /* Light background to blend with the card */
        }

        .card-body {
            padding: 10px;
        }

        .card-title {
            font-size: 16px;
            font-weight: bold;
            margin: 0;
            text-align: center;
        }

        .card-text {
            font-size: 14px;
            text-align: center;
        }
</style>

</head>

<body>
    <div class="header">
        <h1>Atchut Studios</h1>
        <div class="nav">
            <a href="/home.php" class="logo">Logo</a>
            <a href="/Films.php">Films</a>
            <a href="/webseries.php">Web Series</a>
        </div>
    </div>
    <div>
        <!-- Slideshow -->
        <div id="slideshowIndicators" class="carousel slide slideshow" data-ride="carousel">
            <div class="carousel-inner">
                <?php
                $isActive = true;
                while ($data = mysqli_fetch_assoc($slideshow_result)): ?>
                    <div class="carousel-item <?= $isActive ? 'active' : '' ?>">
                        <img src="./image/<?= $data['filename'] ?>" alt="<?= htmlspecialchars($data['title']) ?>">
                        <?php $isActive = false; ?>
                    </div>
                <?php endwhile; ?>
            </div>
            <a class="carousel-control-prev" href="#slideshowIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#slideshowIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>

        <!-- Recent Films Section -->
        <div>
            <div class="section-title">Recent Films</div>
            <div class="card-deck">
                <?php while ($data = mysqli_fetch_assoc($recent_films_result)): ?>
                    <div class="card">
                        <img src="./image/<?= $data['filename'] ?>" alt="<?= htmlspecialchars($data['title']) ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($data['title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($data['description']) ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- Recent Web Series Section -->
        <div>
            <div class="section-title">Recent Web Series</div>
            <div class="card-deck">
                <?php while ($data = mysqli_fetch_assoc($recent_webseries_result)): ?>
                    <div class="card">
                        <img src="./image/<?= $data['filename'] ?>" alt="<?= htmlspecialchars($data['title']) ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($data['title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($data['description']) ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>