<?php
// Database connection
$db_host = 'localhost';
$db_user = 'root';
$db_pass = 'root$1234';
$db_name = 'tutor';

// Create a connection
$db = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

// Check connection
if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get form data (use real POST data in a real form)
$username = 'admin';
$email = 'sairaju.pothumanchi@gmail.com';
$password = 'password';  // You should hash the password before storing it

// Hash the password before storing it in the database for security
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Insert query using prepared statement
$query = "INSERT INTO admin_credentials (username, email, password_hash) VALUES (?, ?, ?)";

// Prepare statement
$stmt = $db->prepare($query);

// Bind parameters
$stmt->bind_param("sss", $username, $email, $hashed_password);

// Execute the query
if ($stmt->execute()) {
    echo "New admin credentials inserted successfully!";
} else {
    echo "Error: " . $stmt->error;
}

// Close statement and connection
$stmt->close();
mysqli_close($db);
?>
