<?php
// Database connection
$db = mysqli_connect("localhost", "root", "root$1234", "tutor");

// Get unique languages for the menu
$language_query = "SELECT DISTINCT language FROM image where type='Film'";
$language_result = mysqli_query($db, $language_query);
$languages = [];
while ($row = mysqli_fetch_assoc($language_result)) {
    $languages[] = $row['language'];
}

// Filter images by language
$filter = isset($_GET['language']) ? $_GET['language'] : 'All';
$image_query = ($filter === 'All') ? "SELECT * FROM image  where type='Film'" : "SELECT * FROM image WHERE language = '$filter' and type='Film'";
$image_result = mysqli_query($db, $image_query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Image Display</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .menu {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }
        .menu a {
            margin: 0 10px;
            text-decoration: none;
            font-weight: bold;
            color: #007bff;
        }
        .menu a.active {
            text-decoration: underline;
            color: #0056b3;
        }
        .gallery {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        .card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            background-color: #f9f9f9;
            text-align: center;
        }
        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 5px;
        }
        .card h5, .card p {
            margin: 10px 0;
        }
        .header {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 15px;
    background: linear-gradient(90deg, #f4f4f4, #eaeaea);
    color: #8B4513; /* Burlywood-like color */
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
  }

  .header h1 {
    margin: 0;
    font-size: 32px;
    font-weight: bold;
  }

  .nav {
    display: flex;
    justify-content: center;
    margin-top: 10px;
    gap: 20px;
  }

  .nav a {
    text-decoration: none;
    color: #8B4513; /* Matching the header color */
    font-size: 18px;
    font-weight: bold;
    transition: color 0.3s ease;
  }

  .nav a:hover {
    color: #DAA520; /* Goldenrod for hover effect */
  }

  .logo {
    font-size: 22px;
    font-weight: bold;
    margin-right: auto;
    color: #8B4513;
  }
    </style>
</head>
<body>
<div class="header">
<h1>Atchut Studios</h1>
  <div class="nav">
    <a href="/home.php" class="logo">Logo</a>
    <a href="/Films.php">Films</a>
    <a href="/webseries.php">Web Series</a>
  </div>
</div>
    <div >
    <div class="menu">
        <a href="?language=All" class="<?= $filter === 'All' ? 'active' : '' ?>">All</a>
        <?php foreach ($languages as $language): ?>
            <a href="?language=<?= urlencode($language) ?>" class="<?= $filter === $language ? 'active' : '' ?>"><?= $language ?></a>
        <?php endforeach; ?>
    </div>

    <div class="gallery">
        <?php while ($data = mysqli_fetch_assoc($image_result)): ?>
        <div class="card">
            <img src="./image/<?= $data['filename'] ?>" alt="<?= htmlspecialchars($data['title']) ?>">
            <h5><?= htmlspecialchars($data['title']) ?></h5>
            <p><?= htmlspecialchars($data['description']) ?></p>
            <p><strong>Language:</strong> <?= htmlspecialchars($data['language']) ?></p>
            <p><strong>Type:</strong> <?= htmlspecialchars($data['type']) ?></p>
            <p><strong>Slideshow:</strong> <?= $data['slideshow'] === 'Y' ? 'Yes' : 'No' ?></p>
            <p><strong>Recent:</strong> <?= $data['recent'] === 'Y' ? 'Yes' : 'No' ?></p>
        </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
